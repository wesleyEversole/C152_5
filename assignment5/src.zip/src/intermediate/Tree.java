/*
 * @Author Tim Stullich , Wesley Eversole
 * Assignment 5 
 * Project for CS 152
 */
package intermediate;

public class Tree {
	Node n;

	public Tree(Node node) {
		this.n = node;
	}

	public Node getNode() {
		return n;
	}
}
